<h1 align="center"><b>TUGAS JAVASCRIPT 1</b></h1>
<hr/>

<h4>Deskripsi Soal :</h4>
<hr/>

<p>
Diketahui: pegawai: Ridwan jabatan: manager status: menikah Tugas: Cetak Data Pegawai berbentuk tabel: Judul Kolom gunakan thead Data2 gunakan tbody Nama Pegawai, Jabatan, Status, Gaji Pokok(if): Manager=>15 jt, Asisten Manager=>10 jt, Staff=>5 jt Tunjangan Jabatan: 15% dari gapok BPJS: 10% dari gapok Tunjangan Keluarga (ternary): dilihat dari status yg sudah menikah =>20% dari gapok Total Gaji: jumlahlahkan seluruh element gaji (gunakan tfoot) </p>
