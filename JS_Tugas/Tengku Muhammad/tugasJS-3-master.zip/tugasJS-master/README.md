<center><h1>TUGAS JAVASCRIPT 2</h1></center>
<hr/>

<p>Studi Independen Bersertifikat NF Computer</p>

<center>
<img src="https://learn.nurulfikri.com/pluginfile.php/1/theme_edumy/headerlogo2/1709107009/logo_nf-computer-ok.png"/>
</center>

<hr/>

<center><h1>TUGAS JAVASCRIPT 3</h1></center>
<hr/>

<p>Studi Independen Bersertifikat NF Computer</p>

<center>
<img src="https://learn.nurulfikri.com/pluginfile.php/1/theme_edumy/headerlogo2/1709107009/logo_nf-computer-ok.png"/>
</center>
